<?php
$CONFIG = array (
  'instanceid' => 'oct57zbmru9p',
  'passwordsalt' => 'P+yeRr5bNBa36kJsM+p8E6HbSZLCfX',
  'secret' => '5r09GvGaf9dpp5Psuz9pIbpt+8auKwY1xsGD0r5VCMk+TE6n',
  'trusted_domains' => 
  array (
    0 => '192.168.137.228',
    1 => '192.168.50.1',
    2 => 'localhost'
  ),
  'datadirectory' => '/var/www/owncloud/data',
  'overwrite.cli.url' => 'http://192.168.50.1',
  'dbtype' => 'mysql',
  'version' => '10.5.0.10',
  'dbname' => 'owncloud',
  'dbhost' => 'localhost',
  'dbtableprefix' => 'oc_',
  'mysql.utf8mb4' => true,
  'dbuser' => 'admin',
  'dbpassword' => 'admin',
  'logtimezone' => 'UTC',
  'apps_paths' => 
  array (
    0 => 
    array (
      'path' => '/var/www/owncloud/apps',
      'url' => '/apps',
      'writable' => false,
    ),
    1 => 
    array (
      'path' => '/var/www/owncloud/apps-external',
      'url' => '/apps-external',
      'writable' => true,
    ),
  ),
  'files_external_allow_create_new_local' => 'true',
  'installed' => true,
);
