#FLASK
from flask import Flask, render_template
app = Flask(__name__)

#DHT11
import Adafruit_DHT
sensor = Adafruit_DHT.DHT11
pin = 18

#BMP280
import board
import busio
import adafruit_bmp280
i2c = busio.I2C(board.SCL, board.SDA)
sensorbmp = adafruit_bmp280.Adafruit_BMP280_I2C(i2c)

#MAIN PROGRAM:
@app.route("/")
def main():
   #DHT:
   humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
   #BMP:
   temperaturebmp = sensorbmp.temperature
   #DATA:
   templateData = {
      'temperature' : temperature,
      'humidity': humidity,
      'temperaturebmp' : temperaturebmp
   }
   return render_template('main.html', **templateData)

if __name__ == "__main__":
   app.run(host='192.168.50.1', port=8080, debug=True)
